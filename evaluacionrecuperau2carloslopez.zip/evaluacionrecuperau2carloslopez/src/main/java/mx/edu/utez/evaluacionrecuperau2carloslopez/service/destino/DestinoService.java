package mx.edu.utez.evaluacionrecuperau2carloslopez.service.destino;

public class DestinoService {
}
